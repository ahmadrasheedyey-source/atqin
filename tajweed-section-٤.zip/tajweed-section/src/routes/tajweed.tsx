import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { TajweedTrainer } from "@/components/tajweed/TajweedTrainer";

export const Route = createFileRoute("/tajweed")({
  head: () => ({
    meta: [
      { title: "التجويد — أتقن القرآن" },
      {
        name: "description",
        content: "استمع لتلاوة شيخ متقن، سجّل قراءتك، واحصل على ملاحظات في أحكام التجويد.",
      },
      { property: "og:title", content: "التجويد — أتقن القرآن" },
      {
        property: "og:description",
        content: "تدرّب على التجويد آية بآية بالرسم العثماني مع تحليل لقراءتك.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: TajweedPage,
});

function TajweedPage() {
  return (
    <div className="min-h-screen bg-background">
      <header className="bg-hero px-5 pb-10 pt-6 text-primary-foreground">
        <div className="mx-auto flex max-w-xl items-center gap-3">
          <Link
            to="/"
            aria-label="الرئيسية"
            className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary-foreground/10"
          >
            <ArrowRight className="h-5 w-5" />
          </Link>
          <div>
            <h1 className="font-display text-2xl">التجويد</h1>
            <p className="text-sm opacity-80">استمع · سجّل · قارن · صحّح</p>
          </div>
        </div>
      </header>
      <main className="relative z-10 mx-auto -mt-6 max-w-xl px-4 pb-8">
        <TajweedTrainer />
      </main>
    </div>
  );
}
