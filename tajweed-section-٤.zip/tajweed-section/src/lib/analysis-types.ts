export type Confidence = "high" | "medium" | "low";
export type RuleStatus = "correct" | "needs_attention" | "uncertain" | "not_present";
export type RuleKey =
  | "madd"
  | "ghunnah"
  | "izhar"
  | "idgham"
  | "ikhfa"
  | "iqlab"
  | "qalqalah"
  | "makharij";

export interface RuleFeedback {
  rule: RuleKey;
  status: RuleStatus;
  confidence: Confidence;
  observation: string;
  how_to_fix: string;
}

export interface WordIssue {
  word: string;
  issue: string;
  how_to_fix: string;
  confidence: Confidence;
}

export interface TajweedAnalysis {
  recording_quality: "good" | "noisy" | "too_quiet" | "too_short" | "unclear";
  recited_matches_ayah: "yes" | "partially" | "no" | "unclear";
  heard_text: string;
  overall_confidence: Confidence;
  summary: string;
  rules: RuleFeedback[];
  word_issues: WordIssue[];
  advice: string;
}

export type AnalysisResult =
  | { ok: true; analysis: TajweedAnalysis; model: string }
  | { ok: false; error: string };

export const AUDIO_FORMATS = ["webm", "m4a", "ogg", "wav", "mp3", "aac"] as const;
export type AudioFormat = (typeof AUDIO_FORMATS)[number];
