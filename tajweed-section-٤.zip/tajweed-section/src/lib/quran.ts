/** Quran data sources (browser-safe). Text & audio from api.alquran.cloud / cdn.islamic.network. */

export const QURAN_API = "https://api.alquran.cloud/v1";

export interface Reciter {
  id: string;
  name: string;
  style: string;
}

export const RECITERS: Reciter[] = [
  { id: "ar.husarymujawwad", name: "محمود خليل الحصري", style: "مجوّد" },
  { id: "ar.minshawimujawwad", name: "محمد صديق المنشاوي", style: "مجوّد" },
  { id: "ar.husary", name: "محمود خليل الحصري", style: "مرتّل" },
  { id: "ar.alafasy", name: "مشاري راشد العفاسي", style: "مرتّل" },
];

export const RECITER_IDS = RECITERS.map((r) => r.id);

export interface SurahMeta {
  number: number;
  name: string;
  englishName: string;
  numberOfAyahs: number;
}

export interface AyahData {
  surah: SurahMeta;
  numberInSurah: number;
  globalNumber: number;
  uthmani: string;
  tajweedMarkup: string;
  audio: string;
  audioFallback?: string | undefined;
}

export async function fetchSurahList(): Promise<SurahMeta[]> {
  const res = await fetch(`${QURAN_API}/surah`);
  if (!res.ok) throw new Error("تعذّر تحميل قائمة السور");
  const json = (await res.json()) as { data: SurahMeta[] };
  return json.data.map((s) => ({
    number: s.number,
    name: s.name,
    englishName: s.englishName,
    numberOfAyahs: s.numberOfAyahs,
  }));
}

interface EditionAyah {
  number: number;
  text: string;
  numberInSurah: number;
  audio?: string;
  audioSecondary?: string[];
  surah: SurahMeta;
}

export async function fetchAyah(surah: number, ayah: number, reciter: string): Promise<AyahData> {
  const res = await fetch(
    `${QURAN_API}/ayah/${surah}:${ayah}/editions/quran-uthmani,quran-tajweed,${reciter}`,
  );
  if (!res.ok) throw new Error("تعذّر تحميل الآية");
  const json = (await res.json()) as { data: EditionAyah[] };
  const [uth, tj, audio] = json.data;
  if (!uth || !tj || !audio?.audio) throw new Error("بيانات الآية غير مكتملة");
  return {
    surah: {
      number: uth.surah.number,
      name: uth.surah.name,
      englishName: uth.surah.englishName,
      numberOfAyahs: uth.surah.numberOfAyahs,
    },
    numberInSurah: uth.numberInSurah,
    globalNumber: uth.number,
    uthmani: uth.text,
    tajweedMarkup: tj.text,
    audio: audio.audio,
    audioFallback: audio.audioSecondary?.[0],
  };
}

/** Next ayah position, wrapping into the next surah (and back to 1:1 after An-Nas). */
export function nextPosition(
  surah: number,
  ayah: number,
  ayahsInSurah: number,
): { surah: number; ayah: number } {
  if (ayah < ayahsInSurah) return { surah, ayah: ayah + 1 };
  if (surah < 114) return { surah: surah + 1, ayah: 1 };
  return { surah: 1, ayah: 1 };
}

export function prevPosition(
  surah: number,
  ayah: number,
  prevSurahAyahs: number | undefined,
): { surah: number; ayah: number } | null {
  if (ayah > 1) return { surah, ayah: ayah - 1 };
  if (surah > 1 && prevSurahAyahs) return { surah: surah - 1, ayah: prevSurahAyahs };
  return null;
}

export function toArabicDigits(n: number): string {
  return String(n).replace(/\d/g, (d) => "٠١٢٣٤٥٦٧٨٩"[Number(d)] ?? d);
}
