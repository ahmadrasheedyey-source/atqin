/**
 * Tajweed helpers built on the color-coded "quran-tajweed" edition from
 * api.alquran.cloud. Markup looks like `[code:id[letters]` or `[code[letters]`.
 * Pure functions only — safe on server and client.
 */

export type TajweedCode =
  | "h" | "s" | "l" | "n" | "p" | "m" | "o" | "q"
  | "c" | "f" | "w" | "i" | "a" | "u" | "d" | "b" | "g";

/** The rule families the analysis reports on. */
export type RuleFamily =
  | "madd"
  | "ghunnah"
  | "izhar"
  | "idgham"
  | "ikhfa"
  | "iqlab"
  | "qalqalah"
  | "silent";

export interface CodeInfo {
  family: RuleFamily;
  name: string;
  /** Tailwind text-color class registered in styles.css */
  colorClass: string;
}

export const CODE_INFO: Record<TajweedCode, CodeInfo> = {
  h: { family: "silent", name: "همزة وصل", colorClass: "text-tj-silent" },
  s: { family: "silent", name: "حرف لا يُنطق", colorClass: "text-tj-silent" },
  l: { family: "silent", name: "لام شمسية", colorClass: "text-tj-silent" },
  n: { family: "madd", name: "مد طبيعي (حركتان)", colorClass: "text-tj-madd" },
  p: { family: "madd", name: "مد جائز (٢ أو ٤ أو ٦ حركات)", colorClass: "text-tj-madd" },
  m: { family: "madd", name: "مد لازم (٦ حركات)", colorClass: "text-tj-madd-lazim" },
  o: { family: "madd", name: "مد واجب متصل (٤ أو ٥ حركات)", colorClass: "text-tj-madd-wajib" },
  q: { family: "qalqalah", name: "قلقلة", colorClass: "text-tj-qalqalah" },
  c: { family: "ikhfa", name: "إخفاء شفوي", colorClass: "text-tj-ikhfa" },
  f: { family: "ikhfa", name: "إخفاء حقيقي", colorClass: "text-tj-ikhfa" },
  w: { family: "idgham", name: "إدغام شفوي", colorClass: "text-tj-idgham" },
  i: { family: "iqlab", name: "إقلاب", colorClass: "text-tj-iqlab" },
  a: { family: "idgham", name: "إدغام بغنة", colorClass: "text-tj-idgham" },
  u: { family: "idgham", name: "إدغام بلا غنة", colorClass: "text-tj-idgham" },
  d: { family: "idgham", name: "إدغام متجانسين", colorClass: "text-tj-idgham" },
  b: { family: "idgham", name: "إدغام متقاربين", colorClass: "text-tj-idgham" },
  g: { family: "ghunnah", name: "غنة (حركتان)", colorClass: "text-tj-ghunnah" },
};

export const FAMILY_LABEL: Record<RuleFamily | "makharij", string> = {
  madd: "المدود",
  ghunnah: "الغنة",
  izhar: "الإظهار",
  idgham: "الإدغام",
  ikhfa: "الإخفاء",
  iqlab: "الإقلاب",
  qalqalah: "القلقلة",
  silent: "الحروف غير المنطوقة",
  makharij: "مخارج الحروف",
};

export interface Segment {
  text: string;
  code?: TajweedCode;
}

const MARKUP = /\[([a-z])(?::\d+)?\[([^\]]*)\]/g;

export function parseTajweed(markup: string): Segment[] {
  const out: Segment[] = [];
  let last = 0;
  for (const m of markup.matchAll(MARKUP)) {
    const idx = m.index ?? 0;
    if (idx > last) out.push({ text: markup.slice(last, idx) });
    const code = m[1] as TajweedCode;
    const text = m[2] ?? "";
    out.push(code in CODE_INFO ? { text, code } : { text });
    last = idx + m[0].length;
  }
  if (last < markup.length) out.push({ text: markup.slice(last) });
  return out;
}

export function stripTajweed(markup: string): string {
  return parseTajweed(markup).map((s) => s.text).join("");
}

export interface RuleOccurrence {
  family: RuleFamily;
  name: string;
  /** The word(s) in which the rule occurs */
  context: string;
}

/** Returns the full word(s) surrounding a character range in `plain`. */
function wordAround(plain: string, start: number, end: number): string {
  let s = start;
  let e = end;
  while (s > 0 && plain[s - 1] !== " ") s--;
  while (e < plain.length && plain[e] !== " ") e++;
  return plain.slice(s, e).trim();
}

/** Rules explicitly marked in the tajweed edition (excludes silent letters). */
export function rulesFromMarkup(markup: string): RuleOccurrence[] {
  const segs = parseTajweed(markup);
  const plain = segs.map((s) => s.text).join("");
  const out: RuleOccurrence[] = [];
  let pos = 0;
  for (const seg of segs) {
    if (seg.code) {
      const info = CODE_INFO[seg.code];
      if (info.family !== "silent") {
        out.push({
          family: info.family,
          name: info.name,
          context: wordAround(plain, pos, pos + seg.text.length),
        });
      }
    }
    pos += seg.text.length;
  }
  return out;
}

const THROAT_LETTERS = new Set(["ء", "أ", "إ", "ؤ", "ئ", "ه", "ع", "ح", "غ", "خ"]);
// Sukun (standard + Uthmani small high dotless head of khah) and tanween forms.
const SUKUN = new Set(["\u0652", "\u06E1"]);
const TANWEEN = new Set(["\u064B", "\u064C", "\u064D", "\u08F0", "\u08F1", "\u08F2"]);
const isArabicLetter = (ch: string) => /[\u0621-\u064A\u0671]/.test(ch);

/**
 * Detects Izhar Halqi (noon sakinah or tanween followed by a throat letter).
 * The tajweed edition does not mark izhar, so this is derived from the text.
 */
export function detectIzhar(plain: string): RuleOccurrence[] {
  const out: RuleOccurrence[] = [];
  const chars = Array.from(plain);
  for (let i = 0; i < chars.length; i++) {
    const ch = chars[i] ?? "";
    let trigger = false;
    if (ch === "ن" && SUKUN.has(chars[i + 1] ?? "")) trigger = true;
    if (TANWEEN.has(ch)) trigger = true;
    if (!trigger) continue;
    // find next base letter
    let j = i + 1;
    while (j < chars.length && !isArabicLetter(chars[j] ?? "")) j++;
    const next = chars[j];
    if (next && THROAT_LETTERS.has(next)) {
      const before = chars.slice(0, i).join("").length;
      const after = chars.slice(0, j + 1).join("").length;
      out.push({
        family: "izhar",
        name: "إظهار حلقي",
        context: wordAround(plain, before, after),
      });
    }
  }
  return out;
}

/** All expected rule occurrences for an ayah, in reading order by family. */
export function expectedRules(markup: string): RuleOccurrence[] {
  const plain = stripTajweed(markup);
  return [...rulesFromMarkup(markup), ...detectIzhar(plain)];
}
