import { describe, expect, it } from "vitest";
import { detectIzhar, expectedRules, parseTajweed, stripTajweed } from "./tajweed";
import { nextPosition } from "./quran";

describe("tajweed markup", () => {
  const fatiha2 = "ٱلْحَمْدُ لِلَّهِ رَبِّ [h:4[ٱ]لْعَ[n[ـٰ]لَم[p[ِي]نَ";

  it("strips markup leaving only Quran text", () => {
    expect(stripTajweed(fatiha2)).toBe("ٱلْحَمْدُ لِلَّهِ رَبِّ ٱلْعَـٰلَمِينَ");
  });

  it("parses rule codes", () => {
    const codes = parseTajweed(fatiha2).filter((s) => s.code).map((s) => s.code);
    expect(codes).toEqual(["h", "n", "p"]);
  });

  it("reports ikhfa and idgham from markup with their word", () => {
    const rules = expectedRules("مَ[f:1375[ن ذ]َا سِنَ[a:1470[ةٌ و]َلَا");
    expect(rules.map((r) => r.family)).toEqual(["ikhfa", "idgham"]);
    expect(rules[0]?.context).toBe("مَن ذَا");
  });
});

describe("izhar detection", () => {
  it("detects noon sakinah before a throat letter", () => {
    expect(detectIzhar("مِنْ هَادٍ").length).toBe(1);
  });
  it("does not flag noon sakinah before a non-throat letter", () => {
    expect(detectIzhar("مِنْ بَعْدِ").length).toBe(0);
  });
});

describe("next ayah", () => {
  it("moves to the next surah after the last ayah", () => {
    expect(nextPosition(1, 7, 7)).toEqual({ surah: 2, ayah: 1 });
  });
  it("advances within a surah", () => {
    expect(nextPosition(2, 3, 286)).toEqual({ surah: 2, ayah: 4 });
  });
});
