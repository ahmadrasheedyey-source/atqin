import { useCallback, useEffect, useRef, useState } from "react";
import type { AudioFormat } from "@/lib/analysis-types";

export type RecorderState = "idle" | "requesting" | "recording" | "stopped" | "error";

export interface Recording {
  blob: Blob;
  url: string;
  format: AudioFormat;
  durationSec: number | null;
}

const CANDIDATES: { mime: string; format: AudioFormat }[] = [
  { mime: "audio/webm;codecs=opus", format: "webm" },
  { mime: "audio/webm", format: "webm" },
  { mime: "audio/mp4", format: "m4a" },
  { mime: "audio/ogg;codecs=opus", format: "ogg" },
];

function pickFormat(): { mime?: string; format: AudioFormat } {
  if (typeof MediaRecorder === "undefined") return { format: "webm" };
  for (const c of CANDIDATES) if (MediaRecorder.isTypeSupported(c.mime)) return c;
  return { format: "webm" };
}

function formatFromMime(mime: string, fallback: AudioFormat): AudioFormat {
  if (mime.includes("mp4") || mime.includes("aac")) return "m4a";
  if (mime.includes("ogg")) return "ogg";
  if (mime.includes("webm")) return "webm";
  return fallback;
}

async function measureDuration(blob: Blob): Promise<number | null> {
  try {
    const Ctx =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return null;
    const ctx = new Ctx();
    const buf = await ctx.decodeAudioData(await blob.arrayBuffer());
    void ctx.close();
    return buf.duration;
  } catch {
    return null;
  }
}

export function useRecorder() {
  const [state, setState] = useState<RecorderState>("idle");
  const [error, setError] = useState<string | null>(null);
  const [recording, setRecording] = useState<Recording | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const mediaRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);

  const cleanupStream = () => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    if (timerRef.current) window.clearInterval(timerRef.current);
    timerRef.current = null;
  };

  const reset = useCallback(() => {
    setRecording((r) => {
      if (r) URL.revokeObjectURL(r.url);
      return null;
    });
    setElapsed(0);
    setError(null);
    setState("idle");
  }, []);

  const start = useCallback(async () => {
    setError(null);
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
      setError("متصفحك لا يدعم التسجيل الصوتي. جرّب متصفح Chrome أو Safari حديث.");
      setState("error");
      return;
    }
    setState("requesting");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      });
      streamRef.current = stream;
      const picked = pickFormat();
      const rec = picked.mime ? new MediaRecorder(stream, { mimeType: picked.mime }) : new MediaRecorder(stream);
      chunksRef.current = [];
      rec.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data);
      };
      rec.onstop = async () => {
        const type = rec.mimeType || picked.mime || "audio/webm";
        const blob = new Blob(chunksRef.current, { type });
        cleanupStream();
        const durationSec = await measureDuration(blob);
        setRecording({
          blob,
          url: URL.createObjectURL(blob),
          format: formatFromMime(type, picked.format),
          durationSec,
        });
        setState("stopped");
      };
      mediaRef.current = rec;
      // No timeslice: one complete file with a valid container header.
      rec.start();
      const startedAt = Date.now();
      setElapsed(0);
      timerRef.current = window.setInterval(() => setElapsed((Date.now() - startedAt) / 1000), 200);
      setRecording((r) => {
        if (r) URL.revokeObjectURL(r.url);
        return null;
      });
      setState("recording");
    } catch (e) {
      cleanupStream();
      const name = (e as { name?: string }).name;
      setError(
        name === "NotAllowedError"
          ? "لم يُسمح بالوصول إلى الميكروفون. فعّل الإذن من إعدادات المتصفح ثم أعد المحاولة."
          : "تعذّر تشغيل الميكروفون على هذا الجهاز.",
      );
      setState("error");
    }
  }, []);

  const stop = useCallback(() => {
    if (mediaRef.current && mediaRef.current.state !== "inactive") mediaRef.current.stop();
  }, []);

  useEffect(
    () => () => {
      if (mediaRef.current && mediaRef.current.state !== "inactive") mediaRef.current.stop();
      cleanupStream();
    },
    [],
  );

  return { state, error, recording, elapsed, start, stop, reset };
}

export function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => {
      const s = String(r.result);
      resolve(s.slice(s.indexOf(",") + 1));
    };
    r.onerror = () => reject(r.error);
    r.readAsDataURL(blob);
  });
}
