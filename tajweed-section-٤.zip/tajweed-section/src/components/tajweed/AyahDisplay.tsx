import { useMemo } from "react";
import { CODE_INFO, parseTajweed } from "@/lib/tajweed";
import { toArabicDigits } from "@/lib/quran";
import { cn } from "@/lib/utils";

interface Props {
  markup: string;
  number: number;
  colored: boolean;
}

export function AyahDisplay({ markup, number, colored }: Props) {
  const segments = useMemo(() => parseTajweed(markup), [markup]);
  return (
    <p dir="rtl" lang="ar" className="quran-text text-center text-[1.9rem] text-primary-deep">
      {segments.map((s, i) =>
        s.code && colored ? (
          <span key={i} className={CODE_INFO[s.code].colorClass} title={CODE_INFO[s.code].name}>
            {s.text}
          </span>
        ) : (
          <span key={i}>{s.text}</span>
        ),
      )}
      <span className="mx-1 inline-flex h-10 w-10 items-center justify-center align-middle font-quran text-lg text-gold-foreground">
        <span className="relative flex h-9 w-9 items-center justify-center rounded-full border-2 border-gold bg-gold-soft">
          {toArabicDigits(number)}
        </span>
      </span>
    </p>
  );
}

const LEGEND: { cls: string; label: string }[] = [
  { cls: "bg-tj-madd", label: "مد" },
  { cls: "bg-tj-madd-wajib", label: "مد واجب/لازم" },
  { cls: "bg-tj-ghunnah", label: "غنة" },
  { cls: "bg-tj-ikhfa", label: "إخفاء" },
  { cls: "bg-tj-idgham", label: "إدغام" },
  { cls: "bg-tj-iqlab", label: "إقلاب" },
  { cls: "bg-tj-qalqalah", label: "قلقلة" },
  { cls: "bg-tj-silent", label: "لا يُنطق" },
];

export function TajweedLegend({ className }: { className?: string }) {
  return (
    <div className={cn("flex flex-wrap justify-center gap-x-3 gap-y-1.5 text-xs text-muted-foreground", className)}>
      {LEGEND.map((l) => (
        <span key={l.label} className="inline-flex items-center gap-1">
          <span className={cn("h-2.5 w-2.5 rounded-full", l.cls)} />
          {l.label}
        </span>
      ))}
    </div>
  );
}
