import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  ChevronLeft,
  ChevronRight,
  Loader2,
  Mic,
  Pause,
  Play,
  RotateCcw,
  Sparkles,
  Square,
  Volume2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { AyahDisplay, TajweedLegend } from "./AyahDisplay";
import { AnalysisPanel } from "./AnalysisPanel";
import { useRecorder, blobToBase64 } from "@/hooks/use-recorder";
import { fetchAyah, fetchSurahList, nextPosition, prevPosition, RECITERS, toArabicDigits } from "@/lib/quran";
import { analyzeRecitation } from "@/lib/api/tajweed.functions";
import type { AnalysisResult } from "@/lib/analysis-types";
import { cn } from "@/lib/utils";

const STORAGE_KEY = "atqin.tajweed.position";

export function TajweedTrainer() {
  const [surah, setSurah] = useState(1);
  const [ayah, setAyah] = useState(1);
  const [reciter, setReciter] = useState<string>(RECITERS[0]?.id ?? "ar.husarymujawwad");
  const [colored, setColored] = useState(true);
  const [restored, setRestored] = useState(false);

  // Restore last position after hydration.
  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "null") as {
        surah?: number; ayah?: number; reciter?: string;
      } | null;
      if (saved?.surah) setSurah(saved.surah);
      if (saved?.ayah) setAyah(saved.ayah);
      if (saved?.reciter && RECITERS.some((r) => r.id === saved.reciter)) setReciter(saved.reciter);
    } catch {
      /* ignore */
    }
    setRestored(true);
  }, []);
  useEffect(() => {
    if (restored) localStorage.setItem(STORAGE_KEY, JSON.stringify({ surah, ayah, reciter }));
  }, [surah, ayah, reciter, restored]);

  const surahs = useQuery({ queryKey: ["surahs"], queryFn: fetchSurahList, staleTime: Infinity });
  const ayahQ = useQuery({
    queryKey: ["ayah", surah, ayah, reciter],
    queryFn: () => fetchAyah(surah, ayah, reciter),
    enabled: restored,
    staleTime: Infinity,
  });
  const data = ayahQ.data;

  // Sheikh audio
  const sheikhRef = useRef<HTMLAudioElement>(null);
  const [sheikhPlaying, setSheikhPlaying] = useState(false);
  const [sheikhDone, setSheikhDone] = useState(false);
  const [sheikhDuration, setSheikhDuration] = useState<number | null>(null);
  const [sheikhError, setSheikhError] = useState(false);

  // User playback
  const mineRef = useRef<HTMLAudioElement>(null);
  const [minePlaying, setMinePlaying] = useState(false);

  const recorder = useRecorder();
  const analyze = useServerFn(analyzeRecitation);
  const mutation = useMutation<AnalysisResult, Error, void>({
    mutationFn: async () => {
      if (!recorder.recording) throw new Error("لا يوجد تسجيل");
      const audioBase64 = await blobToBase64(recorder.recording.blob);
      return analyze({ data: { surah, ayah, reciter, audioBase64, format: recorder.recording.format } });
    },
  });

  // Reset per-ayah state when the ayah changes.
  const { reset: resetRecorder } = recorder;
  const { reset: resetMutation } = mutation;
  useEffect(() => {
    setSheikhDone(false);
    setSheikhPlaying(false);
    setSheikhDuration(null);
    setSheikhError(false);
    setMinePlaying(false);
    resetRecorder();
    resetMutation();
  }, [surah, ayah, reciter, resetRecorder, resetMutation]);

  const toggleSheikh = () => {
    const el = sheikhRef.current;
    if (!el) return;
    if (el.paused) {
      mineRef.current?.pause();
      el.currentTime = el.ended ? 0 : el.currentTime;
      void el.play().catch(() => setSheikhError(true));
    } else el.pause();
  };

  const toggleMine = () => {
    const el = mineRef.current;
    if (!el) return;
    if (el.paused) {
      sheikhRef.current?.pause();
      void el.play();
    } else el.pause();
  };

  const goTo = (pos: { surah: number; ayah: number } | null) => {
    if (!pos) return;
    sheikhRef.current?.pause();
    setSurah(pos.surah);
    setAyah(pos.ayah);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const ayahCount = surahs.data?.find((s) => s.number === surah)?.numberOfAyahs ?? data?.surah.numberOfAyahs;
  const prevCount = surahs.data?.find((s) => s.number === surah - 1)?.numberOfAyahs;
  const result = mutation.data;
  const isRecording = recorder.state === "recording";

  return (
    <div className="space-y-5">
      {/* Selectors */}
      <div className="grid grid-cols-[1fr_auto] gap-2">
        <Select
          value={String(surah)}
          onValueChange={(v) => {
            setSurah(Number(v));
            setAyah(1);
          }}
        >
          <SelectTrigger className="h-12 rounded-xl bg-card text-base">
            <SelectValue placeholder="السورة" />
          </SelectTrigger>
          <SelectContent className="max-h-80">
            {(surahs.data ?? []).map((s) => (
              <SelectItem key={s.number} value={String(s.number)}>
                {toArabicDigits(s.number)}. {s.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={String(ayah)} onValueChange={(v) => setAyah(Number(v))}>
          <SelectTrigger className="h-12 w-28 rounded-xl bg-card text-base">
            <SelectValue placeholder="الآية" />
          </SelectTrigger>
          <SelectContent className="max-h-80">
            {Array.from({ length: ayahCount ?? 1 }, (_, i) => i + 1).map((n) => (
              <SelectItem key={n} value={String(n)}>
                الآية {toArabicDigits(n)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <Select value={reciter} onValueChange={setReciter}>
        <SelectTrigger className="h-12 rounded-xl bg-card text-base">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {RECITERS.map((r) => (
            <SelectItem key={r.id} value={r.id}>
              الشيخ {r.name} — {r.style}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* Ayah card */}
      <div className="relative overflow-hidden rounded-3xl border-2 border-gold/60 bg-ivory p-5 shadow-soft">
        <div className="pointer-events-none absolute inset-0 bg-star-pattern opacity-60" />
        <div className="relative">
          <div className="mb-3 flex items-center justify-between text-sm">
            <span className="font-quran text-lg text-primary">{data?.surah.name ?? "…"}</span>
            <label className="flex items-center gap-2 text-muted-foreground">
              ألوان التجويد
              <Switch checked={colored} onCheckedChange={setColored} />
            </label>
          </div>
          {ayahQ.isLoading || !restored ? (
            <div className="flex h-40 items-center justify-center text-muted-foreground">
              <Loader2 className="h-6 w-6 animate-spin" />
            </div>
          ) : ayahQ.isError || !data ? (
            <div className="space-y-3 py-8 text-center">
              <p className="text-destructive">تعذّر تحميل الآية. تحقق من اتصالك بالإنترنت.</p>
              <Button variant="soft" onClick={() => ayahQ.refetch()}>
                إعادة المحاولة
              </Button>
            </div>
          ) : (
            <>
              <AyahDisplay markup={data.tajweedMarkup} number={data.numberInSurah} colored={colored} />
              {colored && <TajweedLegend className="mt-3" />}
            </>
          )}
        </div>
      </div>

      {/* Step 1: listen */}
      {data && (
        <section className="space-y-3">
          <StepTitle n={1} title="استمع لتلاوة الشيخ" done={sheikhDone} />
          <audio
            ref={sheikhRef}
            src={data.audio}
            preload="auto"
            onPlay={() => setSheikhPlaying(true)}
            onPause={() => setSheikhPlaying(false)}
            onEnded={() => {
              setSheikhPlaying(false);
              setSheikhDone(true);
            }}
            onLoadedMetadata={(e) => setSheikhDuration(e.currentTarget.duration)}
            onError={() => setSheikhError(true)}
          />
          <Button variant="hero" size="xl" className="w-full" onClick={toggleSheikh}>
            {sheikhPlaying ? <Pause /> : <Volume2 />}
            {sheikhPlaying ? "إيقاف مؤقت" : sheikhDone ? "إعادة الاستماع للشيخ" : "استمع للشيخ"}
          </Button>
          {sheikhError && (
            <p className="text-sm text-destructive">تعذّر تشغيل التلاوة. تحقق من الاتصال وأعد المحاولة.</p>
          )}
        </section>
      )}

      {/* Step 2: record */}
      {data && (
        <section className="space-y-3">
          <StepTitle n={2} title="سجّل قراءتك" done={!!recorder.recording} />
          {!sheikhDone && !recorder.recording && !isRecording && (
            <p className="text-sm text-muted-foreground">استمع للشيخ حتى النهاية أولاً، ثم سجّل قراءتك.</p>
          )}
          {isRecording ? (
            <div className="flex flex-col items-center gap-3 rounded-2xl bg-card p-4 shadow-soft">
              <div className="flex items-center gap-2 text-destructive">
                <span className="h-3 w-3 animate-pulse-ring rounded-full bg-destructive" />
                جارٍ التسجيل… {recorder.elapsed.toFixed(0)} ث
              </div>
              <Button variant="record" size="xl" className="w-full" onClick={recorder.stop}>
                <Square />
                إيقاف التسجيل
              </Button>
            </div>
          ) : (
            <Button
              variant={recorder.recording ? "soft" : "record"}
              size="xl"
              className="w-full"
              disabled={!sheikhDone || recorder.state === "requesting"}
              onClick={() => {
                sheikhRef.current?.pause();
                mineRef.current?.pause();
                mutation.reset();
                void recorder.start();
              }}
            >
              {recorder.state === "requesting" ? <Loader2 className="animate-spin" /> : recorder.recording ? <RotateCcw /> : <Mic />}
              {recorder.recording ? "إعادة التسجيل" : "سجّل قراءتي"}
            </Button>
          )}
          {recorder.error && <p className="text-sm text-destructive">{recorder.error}</p>}
        </section>
      )}

      {/* Step 3: compare */}
      {recorder.recording && (
        <section className="space-y-3">
          <StepTitle n={3} title="قارن قراءتك بقراءة الشيخ" done={false} />
          <audio
            ref={mineRef}
            src={recorder.recording.url}
            onPlay={() => setMinePlaying(true)}
            onPause={() => setMinePlaying(false)}
            onEnded={() => setMinePlaying(false)}
          />
          <div className="grid grid-cols-2 gap-2">
            <Button variant="soft" size="xl" onClick={toggleMine}>
              {minePlaying ? <Pause /> : <Play />}
              قراءتي
            </Button>
            <Button variant="soft" size="xl" onClick={toggleSheikh}>
              {sheikhPlaying ? <Pause /> : <Play />}
              الشيخ
            </Button>
          </div>
          <Button
            variant="gold"
            size="xl"
            className="w-full"
            disabled={mutation.isPending}
            onClick={() => mutation.mutate()}
          >
            {mutation.isPending ? <Loader2 className="animate-spin" /> : <Sparkles />}
            {mutation.isPending ? "جارٍ تحليل التلاوة…" : result?.ok ? "إعادة التحليل" : "حلّل تلاوتي"}
          </Button>
          {mutation.isPending && (
            <p className="text-center text-sm text-muted-foreground">
              يستمع المحلّل إلى التسجيلين ويقارن أحكام التجويد، قد يستغرق ذلك نصف دقيقة.
            </p>
          )}
          {mutation.isError && <p className="text-sm text-destructive">تعذّر الاتصال بخدمة التحليل. حاول مرة أخرى.</p>}
          {result && !result.ok && <p className="text-sm text-destructive">{result.error}</p>}
        </section>
      )}

      {/* Step 4: results */}
      {result?.ok && (
        <section className="space-y-3">
          <StepTitle n={4} title="نتيجة التحليل" done />
          <AnalysisPanel
            analysis={result.analysis}
            userDuration={recorder.recording?.durationSec ?? null}
            sheikhDuration={sheikhDuration}
          />
        </section>
      )}

      {/* Navigation */}
      {data && (
        <div className="sticky bottom-3 z-10 grid grid-cols-[auto_1fr] gap-2 pt-2">
          <Button
            variant="soft"
            size="icon-xl"
            aria-label="الآية السابقة"
            disabled={!prevPosition(surah, ayah, prevCount)}
            onClick={() => goTo(prevPosition(surah, ayah, prevCount))}
          >
            <ChevronRight />
          </Button>
          <Button
            variant="hero"
            size="xl"
            onClick={() => goTo(nextPosition(surah, ayah, ayahCount ?? data.surah.numberOfAyahs))}
          >
            الآية التالية
            <ChevronLeft />
          </Button>
        </div>
      )}
    </div>
  );
}

function StepTitle({ n, title, done }: { n: number; title: string; done: boolean }) {
  return (
    <div className="flex items-center gap-2">
      <span
        className={cn(
          "flex h-7 w-7 items-center justify-center rounded-full text-sm font-semibold",
          done ? "bg-primary text-primary-foreground" : "bg-gold-soft text-gold-foreground",
        )}
      >
        {toArabicDigits(n)}
      </span>
      <h2 className="font-display text-lg text-primary-deep">{title}</h2>
    </div>
  );
}
