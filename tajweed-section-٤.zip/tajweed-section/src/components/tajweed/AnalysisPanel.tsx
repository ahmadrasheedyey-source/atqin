import { AlertTriangle, CheckCircle2, CircleHelp, MinusCircle, Info } from "lucide-react";
import type { Confidence, RuleStatus, TajweedAnalysis } from "@/lib/analysis-types";
import { FAMILY_LABEL } from "@/lib/tajweed";
import { cn } from "@/lib/utils";

const STATUS: Record<RuleStatus, { label: string; icon: typeof CheckCircle2; cls: string }> = {
  correct: { label: "يبدو صحيحاً", icon: CheckCircle2, cls: "bg-success-soft text-success" },
  needs_attention: { label: "يحتاج انتباهاً", icon: AlertTriangle, cls: "bg-warning-soft text-warning" },
  uncertain: { label: "غير مؤكد", icon: CircleHelp, cls: "bg-muted text-muted-foreground" },
  not_present: { label: "غير موجود في الآية", icon: MinusCircle, cls: "bg-muted text-muted-foreground" },
};

const CONF: Record<Confidence, string> = { high: "ثقة عالية", medium: "ثقة متوسطة", low: "ثقة منخفضة" };

const QUALITY: Record<TajweedAnalysis["recording_quality"], string> = {
  good: "جودة التسجيل جيدة",
  noisy: "التسجيل فيه ضوضاء",
  too_quiet: "الصوت منخفض جداً",
  too_short: "التسجيل قصير جداً",
  unclear: "التسجيل غير واضح",
};

const MATCH: Record<TajweedAnalysis["recited_matches_ayah"], string> = {
  yes: "القراءة مطابقة لنص الآية",
  partially: "القراءة مطابقة جزئياً",
  no: "القراءة لا تطابق هذه الآية",
  unclear: "تعذّر التحقق من مطابقة النص",
};

interface Props {
  analysis: TajweedAnalysis;
  userDuration: number | null;
  sheikhDuration: number | null;
}

export function AnalysisPanel({ analysis, userDuration, sheikhDuration }: Props) {
  const unreliable =
    analysis.recording_quality !== "good" ||
    analysis.recited_matches_ayah === "no" ||
    analysis.recited_matches_ayah === "unclear";
  const present = analysis.rules.filter((r) => r.status !== "not_present");
  const absent = analysis.rules.filter((r) => r.status === "not_present");

  return (
    <div className="space-y-4">
      <div className="rounded-2xl border border-border bg-card p-4 shadow-soft">
        <div className="mb-2 flex flex-wrap gap-2 text-xs">
          <span className={cn("rounded-full px-2.5 py-1", analysis.recording_quality === "good" ? "bg-success-soft text-success" : "bg-warning-soft text-warning")}>
            {QUALITY[analysis.recording_quality]}
          </span>
          <span className={cn("rounded-full px-2.5 py-1", analysis.recited_matches_ayah === "yes" ? "bg-success-soft text-success" : "bg-warning-soft text-warning")}>
            {MATCH[analysis.recited_matches_ayah]}
          </span>
          <span className="rounded-full bg-gold-soft px-2.5 py-1 text-gold-foreground">
            {CONF[analysis.overall_confidence]}
          </span>
        </div>
        <p className="leading-relaxed text-foreground">{analysis.summary}</p>
        {analysis.heard_text && (
          <div className="mt-3 rounded-xl bg-muted p-3">
            <div className="mb-1 text-xs text-muted-foreground">ما سمعه المحلّل من قراءتك:</div>
            <p className="font-quran text-xl leading-loose text-primary-deep">{analysis.heard_text}</p>
          </div>
        )}
        {userDuration != null && sheikhDuration != null && (
          <p className="mt-3 text-sm text-muted-foreground">
            مدة قراءتك {userDuration.toFixed(1)} ث، ومدة قراءة الشيخ {sheikhDuration.toFixed(1)} ث
            {sheikhDuration > 0 && ` (${Math.round((userDuration / sheikhDuration) * 100)}٪ من زمن الشيخ)`}.
          </p>
        )}
      </div>

      {unreliable && (
        <div className="flex gap-2 rounded-2xl bg-warning-soft p-3 text-sm text-warning">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
          <span>
            {analysis.recited_matches_ayah === "no"
              ? "قراءتك لا تطابق الآية المعروضة، لذلك لم تُقيَّم أحكام التجويد. اقرأ الآية نفسها ثم أعد التسجيل."
              : "لا يمكن الاعتماد على نتائج هذا التسجيل. أعد التسجيل في مكان هادئ وقرّب الهاتف من فمك."}
          </span>
        </div>
      )}

      {analysis.word_issues.length > 0 && (
        <section className="space-y-2">
          <h3 className="font-display text-lg text-primary-deep">مواضع تحتاج مراجعة</h3>
          {analysis.word_issues.map((w, i) => (
            <div key={i} className="rounded-2xl border border-border bg-card p-4">
              <div className="flex items-center justify-between gap-2">
                <span className="font-quran text-2xl text-primary-deep">{w.word}</span>
                <span className="text-xs text-muted-foreground">{CONF[w.confidence]}</span>
              </div>
              <p className="mt-1 text-sm text-foreground">{w.issue}</p>
              <p className="mt-2 rounded-xl bg-secondary p-2.5 text-sm text-secondary-foreground">
                <span className="font-semibold">طريقة التصحيح: </span>
                {w.how_to_fix}
              </p>
            </div>
          ))}
        </section>
      )}

      <section className="space-y-2">
        <h3 className="font-display text-lg text-primary-deep">أحكام التجويد</h3>
        {present.map((r) => {
          const s = STATUS[r.status];
          const Icon = s.icon;
          return (
            <div key={r.rule} className="rounded-2xl border border-border bg-card p-4">
              <div className="flex items-center justify-between gap-2">
                <span className="font-semibold text-primary-deep">{FAMILY_LABEL[r.rule]}</span>
                <span className={cn("inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs", s.cls)}>
                  <Icon className="h-3.5 w-3.5" />
                  {s.label}
                </span>
              </div>
              <p className="mt-2 text-sm leading-relaxed text-foreground">{r.observation}</p>
              {r.status === "needs_attention" && r.how_to_fix && (
                <p className="mt-2 rounded-xl bg-secondary p-2.5 text-sm text-secondary-foreground">
                  <span className="font-semibold">طريقة التصحيح: </span>
                  {r.how_to_fix}
                </p>
              )}
              <p className="mt-2 text-xs text-muted-foreground">{CONF[r.confidence]}</p>
            </div>
          );
        })}
        {absent.length > 0 && (
          <p className="text-xs text-muted-foreground">
            أحكام غير موجودة في هذه الآية: {absent.map((r) => FAMILY_LABEL[r.rule]).join("، ")}
          </p>
        )}
      </section>

      {analysis.advice && (
        <div className="rounded-2xl bg-gold-soft p-4 text-sm leading-relaxed text-gold-foreground">
          <span className="font-semibold">نصيحة: </span>
          {analysis.advice}
        </div>
      )}

      <div className="flex gap-2 rounded-2xl bg-muted p-3 text-xs leading-relaxed text-muted-foreground">
        <Info className="mt-0.5 h-4 w-4 shrink-0" />
        <span>
          هذا التحليل يتم بالذكاء الاصطناعي بمقارنة تسجيلك بتلاوة الشيخ، وهو تقريبي وليس حكماً قطعياً. يُنصح
          بعرض قراءتك على معلم متقن للتأكد.
        </span>
      </div>
    </div>
  );
}
